Font Mfizz Release Notes
===========================================================

## 1.2 - 2013-07-23
 - Moved project to GitHub
 - 14 new icons covering 12 new topics
 - added icon-aws: Amazon Web Services Brand
 - added icon-grails, grails-alt: Grails Framework
 - added icon-c: C programming language
 - added icon-haskell: Haskell Programming Language
 - added icon-ruby-on-rails, icon-ruby-on-rails-alt: Ruby on Rails Framework
 - added icon-clojure: Clojure Programming Language 
 - added icon-heroku: Heroku Brand
 - added icon-dreamhost: Dream Host Brand
 - added icon-centos: CentOS Linux Operating System
 - added icon-fedora: Fedora Linux Operating System
 - added icon-mariadb: Maria DB
 - added icon-redis: Redis DB

## 1.1 - 2013-07-09
 - Added 20 new icons

## 1.0 - 2013-06-29
 - Initial release
